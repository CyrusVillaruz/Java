[Cyrus Villaruz], [A01321323], [Set 1D], [November 8, 2022]

This assignment is [100]% complete.


------------------------
Question one (MultiCylinder) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question two (WordCounter) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question three (Primes) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
Question four (Exponential) status:

[complete]
[explanation if not complete, what is working/not working]

------------------------
